/**
 * @file timer.cpp
 * @author Wuwei YUAN
 * @date 3/8/20
 */

// Nothing in this file